package fallofroyalty;
import javax.swing.JButton;

/**
 *
 * @author Justen
 */
public class GraveyardButton extends JButton{
    private char color;
    private boolean isOccupied;
    private int btnNum;
    
    public GraveyardButton(char color, boolean isOccupied, int btnNum) {
        super();
        this.color = color;
        this.isOccupied = isOccupied;
        this.btnNum = btnNum;
    }
    
    public boolean getOccupancy() {
        return this.isOccupied;
    }
    
    public void setOccupancy(boolean occupancy) {
        this.isOccupied = occupancy;
    }
}
