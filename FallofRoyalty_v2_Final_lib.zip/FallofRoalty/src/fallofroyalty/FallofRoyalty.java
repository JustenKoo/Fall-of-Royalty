package fallofroyalty;
import fallofroyalty.ui.InstructionsWindow;
/**
 * 
 * @author Justen
 */
public class FallofRoyalty {

    public static void main(String[] args) {
        // show players the ruleset
        InstructionsWindow insWin = new InstructionsWindow();
        insWin.setVisible(true);
    }
}
