package fallofroyalty;
import javax.swing.JButton;
import fallofroyalty.GameCharacter;

/**
 *
 * @author Justen
 */
public class JButtonGrid extends JButton{
    private int row;
    private int col;
    private boolean isHighlighted;
    
    public int getRow(){
        return row; 
    }
    
    public int getCol(){
        return col; 
    }
    
    public JButtonGrid(int r, int c, boolean isHL){
        super();
        row = r;
        col = c;
        isHighlighted = isHL;
    }
    
    public String getCoordsText(){
        String rowText = Integer.toString(this.row);
        String colText = Integer.toString(this.col);
        String coordText = ("[" + rowText + "," + colText + "]");
        return coordText;
    }
    
    public void setHL(boolean isHL){
        this.isHighlighted = isHL;
    }
}
