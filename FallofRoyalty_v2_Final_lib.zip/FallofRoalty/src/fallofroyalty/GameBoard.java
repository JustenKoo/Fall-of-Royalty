package fallofroyalty;
import java.util.ArrayList;

/**
 * Stores the locations of the pieces and sends it to GridWin to update the view
 * @author Justen
 */
public class GameBoard {
    private GameTile[][] tileBoard;
    private ArrayList<GameTile> highlightBtn;
    private int newRow;
    private int newCol;
    private int oldRow;
    private int oldCol;
    GameCharacter tmpChar = new GameCharacter("", false, 0, 0, 0, "", 'w');
    GameCharacter deadPiece = new GameCharacter("", false, 0, 0, 0, "", 'w');
    GameCharacter moved = new GameCharacter("", false, 0, 0, 0, "", 'w');
    
    public GameBoard() {
        this.tileBoard = new GameTile[8][8];
        this.highlightBtn = new ArrayList<GameTile>();
        for(int r=0; r<8; r++) {
            for(int c=0; c<8; c++) {
                GameTile tmp = new GameTile(null, false, false, r, c);
                tileBoard[r][c] = tmp;
            }
        }
    }
    
    public void setStartingCoordOwners(Game currGame) {
        ArrayList<GameTile> startingBtns = new ArrayList<GameTile>();
        startingBtns.add(tileBoard[0][2]);
        startingBtns.add(tileBoard[0][5]);
        startingBtns.add(tileBoard[1][2]);
        startingBtns.add(tileBoard[1][3]);
        startingBtns.add(tileBoard[1][4]);
        startingBtns.add(tileBoard[1][5]);
        startingBtns.add(tileBoard[0][4]);
        startingBtns.add(tileBoard[0][3]);
        startingBtns.add(tileBoard[7][2]);
        startingBtns.add(tileBoard[7][5]);
        startingBtns.add(tileBoard[6][2]);
        startingBtns.add(tileBoard[6][3]);
        startingBtns.add(tileBoard[6][4]);
        startingBtns.add(tileBoard[6][5]);
        startingBtns.add(tileBoard[7][3]);
        startingBtns.add(tileBoard[7][4]);
        
        for(int i=0; i<startingBtns.size(); i++) {
            startingBtns.get(i).setOwner(currGame.getPieceFromList(i));
            startingBtns.get(i).setOwnerBool(true);
        }
    }
    
    public int buttonClicked(int r, int c, Game currGame, GamePlayer player1, GamePlayer player2) {
        int responseInt = 5;
        highlightBtn = new ArrayList();
        int pieceRow = r;
        int pieceCol = c;
        GameTile gt = tileBoard[pieceRow][pieceCol];
        boolean isOccupied = gt.getOwnerBool();
        int currRow;
        int currCol;
        
        
        // if the button isn't highlighted already
        if(gt.getHL()== false) {
            if(isOccupied == true) {
                char pieceColor = gt.getOwner().getColor();
                // if user selected the enemy's piece
                if((currGame.getTurn()==true && pieceColor=='b') || (currGame.getTurn()==false && pieceColor=='w')) {
                    if(currGame.getCalidiusUlt()==true) {
                        // kill that piece
                        deadPiece = (gt.getOwner());
                        performLegalMoveCalidius(currGame, gt);
                        checkGameStatus(currGame);
                        resetHL();
                        responseInt = 4;
                    }
                    // return to GridWin and tell user they can't move enemy's piece
                    else
                        responseInt = 0;
                }
                // if user selected their piece
                else {
                    // clear any previous highlights
                    resetHL();
                    // store the selected piece's row and col in a variable
                    tmpChar = gt.getOwner();
                    int tmpMvmt = gt.getOwner().getMvmt();
                    currRow = pieceRow;
                    currCol = pieceCol;
                    highlightBtn.clear();
                        if(currRow == 0 && currCol == 0) {
                            highlightBtn.add(tileBoard[0][1]);
                            highlightBtn.add(tileBoard[1][0]);
                            highlightBtn.add(tileBoard[1][1]);
                        }
                        else if(currRow == 0 && currCol == 7) {
                            highlightBtn.add(tileBoard[0][6]);
                            highlightBtn.add(tileBoard[1][6]);
                            highlightBtn.add(tileBoard[1][7]);
                        }
                        else if(currRow == 7 && currCol == 0) {
                            highlightBtn.add(tileBoard[6][0]);
                            highlightBtn.add(tileBoard[6][1]);
                            highlightBtn.add(tileBoard[7][1]);
                        }
                        else if(currRow == 7 && currCol == 7) {
                            highlightBtn.add(tileBoard[7][6]);
                            highlightBtn.add(tileBoard[6][6]);
                            highlightBtn.add(tileBoard[6][7]);
                        }
                        else if(currRow == 0) {
                            highlightBtn.add(tileBoard[currRow][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol+tmpMvmt]);
                        }
                        else if(currRow == 7) {
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol+tmpMvmt]);
                        }
                        else if(currCol == 0) {
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol+tmpMvmt]);
                        }
                        else if(currCol == 7) {
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol]);
                        }
                        else {
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow-tmpMvmt][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow][currCol+tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol-tmpMvmt]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol]);
                            highlightBtn.add(tileBoard[currRow+tmpMvmt][currCol+tmpMvmt]);
                        }
                    
                    for(int i=0; i < highlightBtn.size(); i++) {
                        if(highlightBtn.get(i).getOwnerBool()==true) {
                            // if the button at this index is a friendly piece
                            if(highlightBtn.get(i).getOwner().getColor()==tmpChar.getColor()) {
                                // do nothing aka dont highlight it
                            }
                            // if the piece at this index is an enemy, highlight it a different color
                            else {
                                highlightBtn.get(i).setEnemyHL(true);
                                highlightBtn.get(i).setHL(true);
                            }
                        }
                        else
                            highlightBtn.get(i).setHL(true);
                    }
                    responseInt = 1;
                }
            }
            else
                resetHL();
        }
        
        else if(gt.getHL()==true) {
            // if desired tile doesn't have an enemy piece, still execute the movement
            if(gt.getOwnerBool()==false){
                // tell GridWin to update the battleLog to a piece moving w/o attacking
                responseInt = 2;
                newRow = pieceRow;
                newCol = pieceCol;
                performLegalMove(gt);
                resetHL();
            }
            else {
                // grab the GameCharacter object that lives at tile set its alive bool to false
                deadPiece = tileBoard[pieceRow][pieceCol].getOwner();
                tileBoard[pieceRow][pieceCol].getOwner().setLife(false);
                // tell GridWin to update the battleLog to a piece attacking another piece
                responseInt = 3;
                newRow = pieceRow;
                newCol = pieceCol;
                performLegalMove(gt);
                checkGameStatus(currGame);
                resetHL();
            }
        }
        return responseInt;
    }
     
    private void resetHL() {
        for(int r=0; r<8; r++){
            for(int c=0; c<8; c++){
                tileBoard[r][c].setHL(false);
                tileBoard[r][c].setEnemyHL(false);
            }
        }
    }
    
    /**
     * 
     * @param gt the clicked tile
     * @param tmpChar the piece moving to gt
     */
    private void performLegalMove(GameTile gt) {
        int gotoR = gt.getRow();
        int gotoC = gt.getCol();
        int currR = tmpChar.getRow();
        int currC = tmpChar.getCol();
        oldRow = currR;
        oldCol = currC;
        
        // set the new button's owner, the boolean and the row and col to the piece being moved
        tileBoard[gotoR][gotoC].setOwner(tmpChar);
        tileBoard[gotoR][gotoC].setOwnerBool(true);
        tmpChar.setNewRow(gotoR);
        tmpChar.setNewCol(gotoC);
        tileBoard[currR][currC].setOwner(null);
        tileBoard[currR][currC].setOwnerBool(false);
    }
    
    private void performLegalMoveCalidius(Game currGame, GameTile gt) {
        int r = gt.getRow();
        int c = gt.getCol();
        tileBoard[r][c].setOwner(null);
        tileBoard[r][c].setOwnerBool(false);
        currGame.setCalidiusUlt(false);
    }
    
    private void checkGameStatus(Game currGame){
        boolean endGame = false;
        if(currGame.getCharacterFromName("Black Queen").getLife()==false && currGame.getCharacterFromName("Black King").getLife()==false)
            endGame = true;
        else if(currGame.getCharacterFromName("White Queen").getLife()==false && currGame.getCharacterFromName("White King").getLife()==false)
            endGame = true;
        if(endGame == true) {
            // return to GridWin and tell it to pull up the Victory Screen
        }
    }
    
    public GameTile[][] getGameBoard() {
        return this.tileBoard;
    }
    
    public GameTile getGameTile(int r, int c) {
        return this.tileBoard[r][c];
    }
    
    public String getMovedCharacter() {
        String pieceName = tileBoard[newRow][newCol].getOwner().getType();
        return pieceName;
    }
    
    public GameCharacter getDeadPiece() {
        return deadPiece;
    }
    
    public int getOldRow() {
        return oldRow;
    }
    
    public int getOldCol() {
        return oldCol;
    }
    
    public int getNewRow() {
        return newRow;
    }
    
    public int getNewCol() {
        return newCol;
    }
    
    public GameCharacter getCurrChar(int r, int c) {
        return tileBoard[r][c].getOwner();
    }
    
    // inner class of GameBoard, represents the tiles on the board
    public class GameTile {
        private GameCharacter owner;
        private boolean isOwned;
        private boolean isHL;
        private boolean enemyHL;
        int row;
        int col;
        
        private GameTile(GameCharacter piece, boolean owned, boolean highlight, int r, int c) {
            this.owner = piece;
            this.isOwned = owned;
            this.isHL = highlight;
            this.row = r;
            this.col = c;
        }
        
        public GameCharacter getOwner() {
            return this.owner;
        }
        
        public void setOwner(GameCharacter tmpChar) {
            this.owner = tmpChar;
        }
        
        public boolean getOwnerBool() {
            return this.isOwned;
        }
        
        public boolean getHL() {
            return this.isHL;
        }
        
        public void setHL(boolean highlight) {
            this.isHL = highlight;
        }
        
        public boolean getEnemyHL() {
            return this.enemyHL;
        }
        
        public void setEnemyHL(boolean highlight) {
            this.enemyHL = highlight;
        }
        
        public void setOwnerBool(boolean owned) {
            this.isOwned = owned;
        }
        
        public int getRow() {
            return this.row;
        }
        
        public int getCol() {
            return this.col;
        }
    }
}
