package fallofroyalty;

/**
 *
 * @author Justen
 */
public class GamePlayer {
    private String name;
    private String kingdom;
    private int currency;
    private int numUnitsAlive;
    private int ultCharge;
    private int playerNum;
    
    public GamePlayer(int playerNum, String name, String kingdom, int currency, int numUnitsAlive, int ultCharge){
        this.playerNum = playerNum;
        this.name = name;
        this.kingdom = kingdom;
        this.currency = currency;
        this.numUnitsAlive = numUnitsAlive;
        this.ultCharge = ultCharge;
    }
    
    public int getPlayerNum(){
        return this.playerNum;
    }
    
    public int getUltCharge(){
        return this.ultCharge;
    }
    
    public void addUltCharge(int value){
        this.ultCharge = this.ultCharge + value;
    }
    
    public int setUltCharge(int value){
        this.ultCharge = value;
        return this.ultCharge;
    }
    
    public String getName(){
        return name;
    }
    
    public String getKingdom(){
        return kingdom;
    }
    
    public String getGold(){
        String gold = currency + "G";
        return gold;
    }
    
    public int getGold(int currency){
        return currency;
    }
    
    public int addGold(int income){
        currency += income;
        return currency;
    }
    
    public int removeGold(int income){
        currency -= income;
        return currency;
    }
    
    public void setGold(int gold){
        this.currency = gold;
    }
    
    public int getNumUnits(){
        return this.numUnitsAlive;
    }
}