package fallofroyalty.t4j;
import twitter4j.Twitter;
import twitter4j.Status;
import twitter4j.TwitterFactory;
import twitter4j.TwitterException;
import twitter4j.conf.ConfigurationBuilder;

/**
 *
 * @author Justen
 */
public class TwitterBot {
    private boolean enableTweet;
    
    public TwitterBot(boolean enableTweet) {
        this.enableTweet = enableTweet;
    }
    
    public boolean getTweetPerm() {
        return enableTweet;
    }
    
    public void setTweetPerm(boolean enabled) {
        this.enableTweet = enabled;
    }
    
    public void sendTweet(String message) {
        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
        .setOAuthConsumerKey("YXoEPx3TqgnvnU6uJ2oR4opx1")
        .setOAuthConsumerSecret("uzh4cSFofGNwOsT7JxpAv6JrZNCNEVjfWREQStr15X9Uat0YnX")
        .setOAuthAccessToken("1248020668735729666-eDsZErhjVGRmz9nSNvRSdpo0YHZQp6")
        .setOAuthAccessTokenSecret("BlEbgWdGUN7CPzP18rZslLCc9reKTuVYKwA6QV2AmSKkw");
        TwitterFactory tf = new TwitterFactory(cb.build());
        Twitter twitter = tf.getInstance();
        try {
            Status status = twitter.updateStatus(message);
            System.out.println("Successfully updated the status to [" + status.getText() + "].");
        } catch(TwitterException e) {
            e.printStackTrace();
        }
    }
}
