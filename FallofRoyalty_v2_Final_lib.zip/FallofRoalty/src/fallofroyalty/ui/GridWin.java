package fallofroyalty.ui;
import fallofroyalty.JButtonGrid;
import fallofroyalty.GraveyardButton;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import javax.swing.JOptionPane;
import fallofroyalty.GamePlayer;
import fallofroyalty.GameCharacter;
import fallofroyalty.Game;
import fallofroyalty.GameBoard;
import static fallofroyalty.SpellUltimate.ultActivated;
import fallofroyalty.t4j.TwitterBot;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

/**
 *
 * @author Justen
 */
public class GridWin extends javax.swing.JFrame{
    private final JButtonGrid[][] allButtons;
    private GameBoard gameBoard;
    private ArrayList<GraveyardButton> whiteGYBtns; // array list of the white graveyard buttons
    private ArrayList<GraveyardButton> blackGYBtns; // array list of the black graveyard buttons
    private static GamePlayer player1;
    private static GamePlayer player2;
    private static Game currGame;
    boolean nextbtnisBlack = true;
    TwitterBot tb = new TwitterBot(false);
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public GridWin(GamePlayer player1, GamePlayer player2, Game currGame) {
        initComponents();
        gameBoard = new GameBoard();
        btnPTurn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-white.png")));
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        // creates a 2D array of JButtons
        allButtons = new JButtonGrid[8][8];
        // establishes the color for the JButton grid
        for(int r=0; r<8; r++){
            for(int c=0; c<8; c++){
                boolean isHL = false;
                JButtonGrid tmp = new JButtonGrid(r,c,isHL);
                tmp.setFont(new Font("Arial", Font.BOLD, 11));
                tmp.setText(r + "," + c);
                tmp.setSize(50,50);
                tmp.setLocation(c*50+100, r*50+150);
                
                if(nextbtnisBlack==true){   
                    tmp.setBackground(Color.GRAY);
                    nextbtnisBlack = false;
                    if(c==7)
                        nextbtnisBlack = true;
                }
                else{
                    tmp.setBackground(Color.WHITE);
                    nextbtnisBlack = true;
                    if(c==7)
                        nextbtnisBlack = false;
                }
                tmp.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        buttonClicked(evt);
                    }
                });
                allButtons[r][c] = tmp;
                this.add(tmp);       
            }
        }
        
        whiteGYBtns = new ArrayList<GraveyardButton>();
        blackGYBtns = new ArrayList<GraveyardButton>();
        // creates and sets the locations of the GY buttons
        for(int i=0; i<8; i++) {
            GraveyardButton tmpGYB = new GraveyardButton('w', false, i);
            whiteGYBtns.add(tmpGYB);
            tmpGYB.setFont(new Font("Arial", Font.BOLD, 11));
            tmpGYB.setSize(50,50);
            tmpGYB.setLocation(10, i*50+150);
            tmpGYB.setEnabled(false);
            
            GraveyardButton tmpbGYB = new GraveyardButton('b', false, i);
            blackGYBtns.add(tmpbGYB);
            tmpbGYB.setFont(new Font("Arial", Font.BOLD, 11));
            tmpbGYB.setSize(50,50);
            tmpbGYB.setLocation(545, i*50+150);
            tmpbGYB.setEnabled(false);
            
            this.add(tmpGYB);
            this.add(tmpbGYB);
        }
        
        this.pack();
        this.player1 = player1;
        this.player2 = player2;
        this.currGame = currGame;
        gameBoard.setStartingCoordOwners(this.currGame);
        updateBoard();
        // set labels and assign kingdoms and leaders
        lblP1Name.setText(player1.getName());
        lblP1Gold.setText(player1.getGold());
        lblP1Kingdom.setText(player1.getKingdom());
        lblP2Name.setText(player2.getName());
        lblP2Gold.setText(player2.getGold());
        lblP2Kingdom.setText(player2.getKingdom());
        lblTurnNum.setText(currGame.getTurnNumText());
        lblPTurn.setText(player1.getName() + "'s Turn");
    }
    
    /**
     * If the clicked button isn't highlighted and is occupied by a piece, it highlights the legal buttons that it can move to
     * if the clicked button is highlighted, this function moves the previously clicked piece to the clicked button
     * @param evt 
     */
    private void buttonClicked(java.awt.event.ActionEvent evt) {
        // figure out which button was clicked
        JButtonGrid jb = (JButtonGrid)evt.getSource();
        
        // send GameBoard pieceRow and pieceCol
        int responseInt = gameBoard.buttonClicked(jb.getRow(), jb.getCol(), currGame, player1, player2);
        resetView();
        // user clicked on an enemy piece; tell them that they can't do that
        switch(responseInt) {
            // user clicks on an enemy piece; open a JOptionPane saying that they can't do that
            case 0:
                JOptionPane.showInternalMessageDialog(null,"Can't Move Enemy Piece","Error: Illegal Move",JOptionPane.ERROR_MESSAGE);
                break;
            // user clicks on their own piece; update the view    
            case 1:
                updateBoard();
                break;
            // user moves their piece to a vacant tile; update the view and the battleLog
            case 2:
                updateBoard();
                updateBL();
                updateGameView();
                break;
            // user attacks the enemy's piece; update the view and the battleLog
            case 3:
                updateBoard();
                updateBLElim();
                updateGameView();
                break;
            // user uses Calidius ult
            case 4:
                updateBoard();
                updateBLCalidius();
                updateGameView();
                break;
        }
    }
    
    /**
     * requests GameBoard for its 2D array and updates allButtons(what the user sees/interacts with) accordingly
     */
    private void updateBoard() {
        for(int r=0; r<8; r++) {
            for(int c=0; c<8; c++) {
                // if the current coord has a piece
                if(gameBoard.getGameTile(r, c).getOwnerBool()==true) {
                    // figure out what kind of piece it is
                    GameCharacter tmpChar = gameBoard.getGameTile(r, c).getOwner();
                        // set the icon of allButtons[r][c] to the appropriate icon
                        if(tmpChar.getType()=="pawn") {
                            if(tmpChar.getColor()=='w')
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-white.png")));
                            else
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-black.png")));
                        }
                        else if(tmpChar.getType()=="queen") {
                            if(tmpChar.getColor()=='w')
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/queen-white.png")));
                            else
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/queen-black.png")));
                        }
                        else if(tmpChar.getType()=="king") {
                            if(tmpChar.getColor()=='w')
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/king-white.png")));
                            else
                                allButtons[r][c].setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/king-black.png")));
                        }
                }
                else if(gameBoard.getGameTile(r, c).getOwnerBool()==false)
                    allButtons[r][c].setIcon(null);
                // if the current coord is highlighted
                if(gameBoard.getGameTile(r, c).getHL()==true)
                    allButtons[r][c].setBackground(Color.CYAN);
                // if the current coord is highlighted and has an enemy
                if(gameBoard.getGameTile(r, c).getEnemyHL()==true)
                    allButtons[r][c].setBackground(Color.RED);
            }
        }
        checkGameStatus();
    }
    
    /**
     * updates the battle log when a user moves to a vacant location
     */
    public void updateBL() {
        if(currGame.getTurn()==true){
            String battleLog = (player1.getName() + "'s " + gameBoard.getMovedCharacter() + " moved from [" + gameBoard.getOldRow() + "," + gameBoard.getOldCol() + "]"  + " to "  + allButtons[gameBoard.getNewRow()][gameBoard.getNewCol()].getCoordsText());
            jtaBattleLog.setText(battleLog);
        }
        else {
            String battleLog = (player2.getName() + "'s " + gameBoard.getMovedCharacter() + " moved from [" + gameBoard.getOldCol() + "," + gameBoard.getOldCol() +  "]" + " to "  + allButtons[gameBoard.getNewRow()][gameBoard.getNewCol()].getCoordsText());
            jtaBattleLog.setText(battleLog);
        }
    }
    
    /**
     * updates the battle log when a user attacks the enemy
     */
    public void updateBLElim() {
        String battleLog = "";
        if(currGame.getTurn()==true){
            player1.addGold(500);
            battleLog = (player1.getName() + "'s " + gameBoard.getMovedCharacter() + " killed " + player2.getName() + "'s " + gameBoard.getCurrChar(gameBoard.getNewRow(), gameBoard.getNewCol()).getType());
            jtaBattleLog.setText(battleLog);
        }
        else if(currGame.getTurn()==false){
            player2.addGold(500);
            battleLog = (player2.getName() + "'s " + gameBoard.getMovedCharacter() + " killed " + player1.getName() + "'s " + gameBoard.getCurrChar(gameBoard.getNewRow(), gameBoard.getNewCol()).getType());
            jtaBattleLog.setText(battleLog);
        }
        if(tb.getTweetPerm()==true)
            tb.sendTweet(battleLog);
        updateGraveyard(gameBoard.getDeadPiece());
    }
    
    public void updateBLCalidius() {
        String battleLog = "";
        if(currGame.getTurn()==true){
            player1.addGold(500);
            battleLog = (player1.getName() + " burnt " + player2.getName() + "'s " + gameBoard.getDeadPiece().getType());
            jtaBattleLog.setText(battleLog);
        }
        else if(currGame.getTurn()==false){
            player2.addGold(500);
            battleLog = (player2.getName() + " burnt " + player1.getName() + "'s " + gameBoard.getDeadPiece().getType());
            jtaBattleLog.setText(battleLog);
        }
        if(tb.getTweetPerm()==true)
            tb.sendTweet(battleLog);
        updateGraveyard(gameBoard.getDeadPiece());
    }
    
    public void updateBLUlt(String ult) {
        jtaBattleLog.setText(ult);
        if(tb.getTweetPerm()==true)
            tb.sendTweet(ult);
    }
    
    
    /**
     * resets the highlighting, makes the board back to default checkered
     */
    public void resetView() {
        for(int r=0; r<8; r++){
            for(int c=0; c<8; c++){
                if(nextbtnisBlack == true){   
                    allButtons[r][c].setBackground(Color.GRAY);
                    allButtons[r][c].setHL(false);
                    nextbtnisBlack = false;
                    if(c == 7)
                        nextbtnisBlack = true;
                }
                else{
                    allButtons[r][c].setBackground(Color.WHITE);
                    allButtons[r][c].setHL(false);
                    nextbtnisBlack = true;
                    if(c == 7)
                        nextbtnisBlack = false;
                }   
            }
        }
    }
    
    /**
     * takes in GameCharacter character, finds the next empty spot in the respective graveyard, and places the image there
     * @param character - the GameCharacter that was defeated
     */
    public void updateGraveyard(GameCharacter character){
        if(character.getColor()=='w') {
            // iterate over the arraylist of graveyard buttons and find an empty spot
            for(int i=0; i<whiteGYBtns.size(); i++) {
                // once the empty spot is found, put the recently defeated piece at that button
                if(whiteGYBtns.get(i).getOccupancy() == false) {
                    if(character.getType()=="pawn")
                        whiteGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-white.png")));
                    if(character.getType()=="queen")
                        whiteGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/queen-white.png")));
                    if(character.getType()=="king")
                        whiteGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/king-white.png")));
                    whiteGYBtns.get(i).setOccupancy(true);
                    break;
                }
            }
        }
        else {
            for(int i=0; i<blackGYBtns.size(); i++) {
                if(blackGYBtns.get(i).getOccupancy() == false) {
                    if(character.getType()=="pawn")
                        blackGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-black.png")));
                    if(character.getType()=="queen")
                         blackGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/queen-black.png")));
                    if(character.getType()=="king")
                         blackGYBtns.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/king-black.png")));
                     blackGYBtns.get(i).setOccupancy(true);
                    break;
                }
            }
        }
    }
    
    /**
     * asks Game to update itself, then makes text/lbl changes based on the updates
     */
    public void updateGameView(){
        if(currGame.getFroldianUlt()==true) {
            if(currGame.getTurn()==true)
                currGame.updateGameFroldianUlt(player1);
            else
                currGame.updateGameFroldianUlt(player2);
        }
        else if(currGame.getCalidiusUlt()==true) {
            if(currGame.getTurn()==true) {
                currGame.updateGameCalidiusUlt(player1);
            }
            else {
                currGame.updateGameCalidiusUlt(player2);
            }
        }
        else {
            currGame.updateGame(player1, player2);
            lblP1Gold.setText(player1.getGold());
            lblP2Gold.setText(player2.getGold());
            p1UltCharge.setValue(player1.getUltCharge());
            p1UltCharge.setString(Integer.toString(player1.getUltCharge()));
            p2UltCharge.setValue(player2.getUltCharge());
            p2UltCharge.setString(Integer.toString(player2.getUltCharge()));
            lblTurnNum.setText(currGame.getTurnNumText());
            if(currGame.getTurn()==true){
                lblPTurn.setText(player1.getName() + "'s Turn");
                btnPTurn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-white.png")));
            }
            else if(currGame.getTurn()==false){
                lblPTurn.setText(player2.getName() + "'s Turn");
                btnPTurn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fallofroyalty/ui/resources/pawn-black.png"))); 
            }
        }
    }
    
    /**
     * asks Game to check if the game is won, if it is, bring up the Victory message and tweet if enabled
     */
    public void checkGameStatus(){
        String victoryMessage = "";
        boolean endGame = false;
        int status = currGame.checkGameStatus();
        if(status==1) {
            victoryMessage = (player1.getName() + " of the " + player1.getKingdom() + " won!" );
            endGame = true;
        }
        else if(status==2) {
            victoryMessage = (player2.getName() + " of the " + player2.getKingdom() + " won!" );
            endGame = true;
        }
        if(tb.getTweetPerm()==true) 
            tb.sendTweet(victoryMessage);
        if(endGame == true) {
            Object[] options = {"Play With the Same Players",
                                "Play With New Players",
                                "Exit to the Main Menu",
                                "Quit Fall of Royalty"};
            int option = JOptionPane.showOptionDialog(null,victoryMessage,"Royalty Has Fallen!",
                                                        JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,
                                                        null,options,options[2]);
            switch(option) {
                case 0:
                    Game newGame = Game.FromScratch();
                    // reset the gold and ult charges
                    player1.setUltCharge(0);
                    player2.setUltCharge(0);
                    player1.setGold(0);
                    player2.setGold(0);
                    GridWin newWin = new GridWin(player1, player2, newGame);
                    this.dispose();
                    newWin.setVisible(true);
                    break;
                case 1:
                    this.dispose();
                    EnterPlayerInfoWin epi = new EnterPlayerInfoWin();
                    epi.setVisible(true);
                    break;
                case 2:
                    this.dispose();
                    InstructionsWindow insWin = new InstructionsWindow();
                    insWin.setVisible(true);
                    break;
                default:
                    System.out.println("Quitting Fall of Royalty...");
                    System.exit(0);
                    break;
            }
        }
    }
    
    /**
     * Captures the Game, player1 and player2, converts into a String and 
     * exports it into a txt file at user's preferred location
     * @param saveFile - File created and named by the user
     */
    public void saveGame(File saveFile) {
        Gson gson = new Gson();
        String game = gson.toJson(currGame);
        String p1 = gson.toJson(player1);
        String p2 = gson.toJson(player2);
        
        StringBuilder sb = new StringBuilder();
        sb.append("{\n\tGame Info:");
        sb.append(game);
        sb.append(",\n\tPlayer 1 Info: ");
        sb.append(p1);
        sb.append(",\n\tPlayer 2 Info: ");
        sb.append(p2);
        sb.append("\n}");
        
        try {
            FileWriter myWriter = new FileWriter(saveFile);
            myWriter.write(sb.toString());
            myWriter.close();
        System.out.println("Saved " + saveFile + ".txt");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    
    /**
     * Loads the game from a txt file
     * @param file - txt file that user selects
     */
    public void loadGame(File file) {
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            JsonParser jparser = new JsonParser();
            JsonElement rootElement = jparser.parse(br);
            JsonObject rootObject = rootElement.getAsJsonObject();
            JsonObject game = rootObject.getAsJsonObject("Game Info: ");
            JsonObject p1 = rootObject.getAsJsonObject("Player 1 Info: ");
            JsonObject p2 = rootObject.getAsJsonObject("Player 2 Info: ");
            
            Gson gson = new Gson();
            this.currGame = gson.fromJson(game, Game.class);
            this.player1 = gson.fromJson(p1, GamePlayer.class);
            this.player2 = gson.fromJson(p2, GamePlayer.class);
            
            } catch (IOException ex) {
                Logger.getLogger(GridWin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        p1UltCharge = new javax.swing.JProgressBar();
        p2UltCharge = new javax.swing.JProgressBar();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaBattleLog = new javax.swing.JTextArea();
        lblTurnNum = new javax.swing.JLabel();
        btnShop = new javax.swing.JButton();
        btnCast = new javax.swing.JButton();
        lblP1Name = new javax.swing.JLabel();
        lblP1Gold = new javax.swing.JLabel();
        lblP1Kingdom = new javax.swing.JLabel();
        lblP2Name = new javax.swing.JLabel();
        lblP2Gold = new javax.swing.JLabel();
        lblP2Kingdom = new javax.swing.JLabel();
        lblPTurn = new javax.swing.JLabel();
        btnPTurn = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuLoadGame = new javax.swing.JMenu();
        jMenuSaveGame = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtaBattleLog.setColumns(20);
        jtaBattleLog.setRows(5);
        jScrollPane2.setViewportView(jtaBattleLog);

        lblTurnNum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnNum.setText("jLabel7");
        lblTurnNum.setToolTipText("");
        lblTurnNum.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblTurnNum.setLocation(dim.width/2-this.getSize().width/2,0);

        btnShop.setText("Shop");
        btnShop.setEnabled(false);

        btnCast.setText("Spell");
        btnCast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCastActionPerformed(evt);
            }
        });

        lblP1Name.setText("jLabel1");

        lblP1Gold.setText("jLabel2");

        lblP1Kingdom.setText("jLabel3");

        lblP2Name.setText("jLabel4");

        lblP2Gold.setText("jLabel5");

        lblP2Kingdom.setText("jLabel6");

        lblPTurn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPTurn.setText("jLabel1");
        lblPTurn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblPTurn.setLocation(dim.width/2-this.getSize().width/2, 5);

        btnPTurn.setOpaque(false);
        btnPTurn.setEnabled(false);

        jMenuLoadGame.setText("Load");
        jMenuLoadGame.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuLoadGameMouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenuLoadGame);

        jMenuSaveGame.setText("Save");
        jMenuSaveGame.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuSaveGameMouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenuSaveGame);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnShop, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(154, 154, 154)
                                .addComponent(btnCast, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 143, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p1UltCharge, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblP1Name)
                            .addComponent(lblP1Gold)
                            .addComponent(lblP1Kingdom))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTurnNum, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPTurn, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnPTurn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(93, 93, 93)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p2UltCharge, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblP2Kingdom, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblP2Gold, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblP2Name, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTurnNum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPTurn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPTurn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblP1Name)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblP1Gold)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblP1Kingdom)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(p1UltCharge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblP2Name)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblP2Gold)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblP2Kingdom)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(p2UltCharge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(474, 474, 474)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnShop)
                    .addComponent(btnCast)))
        );

        lblP1Name.getAccessibleContext().setAccessibleName("lblP1Name");
        lblP1Gold.getAccessibleContext().setAccessibleName("lblP1Gold");
        lblP1Kingdom.getAccessibleContext().setAccessibleName("lblP1Kingdom");
        lblP2Name.getAccessibleContext().setAccessibleName("lblP2Name");
        lblP2Gold.getAccessibleContext().setAccessibleName("lblP2Gold");
        lblP2Kingdom.getAccessibleContext().setAccessibleName("lblP2Kingdom");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCastActionPerformed
        if(currGame.getTurn()==true) {
            if(player1.getUltCharge()>=100){
                String usedUltText = ultActivated(currGame, player1, player2);
                updateBLUlt(usedUltText);
            }
            else
                JOptionPane.showInternalMessageDialog(null,"Ultimate Spell Not Ready","Error: Insufficient Ultimate Charge",JOptionPane.ERROR_MESSAGE);
        }
        else {
            if(player2.getUltCharge()>=100){
                String usedUltText = ultActivated(currGame, player2, player1);
                updateBLUlt(usedUltText);
            }
            else
                JOptionPane.showInternalMessageDialog(null,"Ultimate Spell Not Ready","Error: Insufficient Ultimate Charge",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnCastActionPerformed

    private void jMenuLoadGameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuLoadGameMouseClicked
        JFileChooser jfc = new JFileChooser();
        int retval = jfc.showSaveDialog(this);
        if (retval == JFileChooser.APPROVE_OPTION) {
            File saveFile = jfc.getSelectedFile();
            loadGame(saveFile);
        }
    }//GEN-LAST:event_jMenuLoadGameMouseClicked

    private void jMenuSaveGameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuSaveGameMouseClicked
        // open the file chooser menu and allow them to save the game then bring them back to the game
        JFileChooser jfc = new JFileChooser();
        int retval = jfc.showSaveDialog(this);
        if(retval == JFileChooser.APPROVE_OPTION) {
            File saveFile = jfc.getSelectedFile();
            saveGame(saveFile);
        }
    }//GEN-LAST:event_jMenuSaveGameMouseClicked
    public static void main(String args[]) {
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GridWin(player1, player2, currGame).setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCast;
    private javax.swing.JButton btnPTurn;
    private javax.swing.JButton btnShop;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuLoadGame;
    private javax.swing.JMenu jMenuSaveGame;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jtaBattleLog;
    private javax.swing.JLabel lblP1Gold;
    private javax.swing.JLabel lblP1Kingdom;
    private javax.swing.JLabel lblP1Name;
    private javax.swing.JLabel lblP2Gold;
    private javax.swing.JLabel lblP2Kingdom;
    private javax.swing.JLabel lblP2Name;
    private javax.swing.JLabel lblPTurn;
    private javax.swing.JLabel lblTurnNum;
    private javax.swing.JProgressBar p1UltCharge;
    private javax.swing.JProgressBar p2UltCharge;
    // End of variables declaration//GEN-END:variables
}