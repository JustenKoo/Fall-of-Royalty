package fallofroyalty;

/**
 *
 * @author Justen
 */
public abstract class SpellUltimate{
    
    /* Method to figure out who activated their ult, and which ult specifically
    */
    public static String ultActivated(Game currGame, GamePlayer user, GamePlayer victim){
        String ultUsedText = "";
        if(user.getKingdom()=="Froldian Empire(Ice)")
            ultUsedText = froldianUlt(currGame, user, victim);
        else if(user.getKingdom()=="Calidius Coalition(Sun)")
            ultUsedText = calidiusUlt(currGame, user, victim);
        else if(user.getKingdom()=="Kingdom of Ventor(Wind)")
            ultUsedText = ventorUlt(currGame, user, victim);
        else if(user.getKingdom()=="Kingdom of Luto(Earth)")
            ultUsedText = lutoUlt(currGame, user, victim);
        return ultUsedText;
    }
    
    private static String froldianUlt(Game currGame, GamePlayer user, GamePlayer victim) {
        currGame.setFroldianUlt(true);
        String userName = user.getName();
        String victimName = victim.getName();
        String ultUsedText = userName + " used Froldian Freeze! " + victimName + "'s units are frozen for 1 turn!";
        return ultUsedText;
    }
    
    private static String calidiusUlt(Game currGame, GamePlayer user, GamePlayer victim) {
        currGame.setCalidiusUlt(true);
        String userName = user.getName();
        String victimName = victim.getName();
        String ultUsedText = userName + " used Star of Calidius! One of " + victimName + "'s units burns!";
        return ultUsedText;
    }
    
    private static String ventorUlt(Game currGame, GamePlayer user, GamePlayer victim) {
        //currGame.setVenUltActive(true);
        String userName = user.getName();
        String victimName = victim.getName();
        String ultUsedText = userName + " used Ventori Wind! " + victimName + " loses 30 sec. from there timer for 3 turns!";
        return ultUsedText;
    }
    
    private static String lutoUlt(Game currGame, GamePlayer user, GamePlayer victim) {
        //currGame.setLutoUltActive(true);
        String userName = user.getName();
        String victimName = victim.getName();
        String ultUsedText = userName + " used Lutonian Barrier! " + victimName + "'s units can't pass over the barrier!";
        return ultUsedText;
    }
}