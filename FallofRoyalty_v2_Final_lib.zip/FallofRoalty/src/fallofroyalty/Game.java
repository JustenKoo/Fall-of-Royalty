package fallofroyalty;
import java.util.ArrayList;

/**
 *
 * @author Justen
 */
public class Game {
    private int turnNum;
    private boolean gameOver;
    private boolean player1Turn;
    private final ArrayList<GameCharacter> allPieces; // array list of all of the pieces
    private static Game game = null;
    private GameBoard gb;
    private boolean froldianUltActive = false;
    private boolean calidiusUltActive = false;
    private boolean ventorUltActive = false;
    private boolean lutoUltActive = false;
    
    private Game(int turnNum, boolean gameOver, boolean player1Turn){
        ArrayList<GameCharacter> aP = new ArrayList<GameCharacter>();
        GameCharacter whitePawn1 = new GameCharacter("White Pawn 1", true, 1, 0, 2, "pawn", 'w');
        GameCharacter whitePawn2 = new GameCharacter("White Pawn 2", true, 1, 0, 5, "pawn", 'w');
        GameCharacter whitePawn3 = new GameCharacter("White Pawn 3", true, 1, 1, 2, "pawn", 'w');
        GameCharacter whitePawn4 = new GameCharacter("White Pawn 4", true, 1, 1, 3, "pawn", 'w');
        GameCharacter whitePawn5 = new GameCharacter("White Pawn 5", true, 1, 1, 4, "pawn", 'w');
        GameCharacter whitePawn6 = new GameCharacter("White Pawn 6", true, 1, 1, 5, "pawn", 'w');
        GameCharacter whiteQueen = new GameCharacter("White Queen", true, 2, 0, 4, "queen", 'w');
        GameCharacter whiteKing = new GameCharacter("White King", true, 1, 0, 3, "king", 'w');
        GameCharacter blackPawn1 = new GameCharacter("Black Pawn 1", true, 1, 7, 2, "pawn", 'b');
        GameCharacter blackPawn2 = new GameCharacter("Black Pawn 2", true, 1, 7, 5, "pawn", 'b');
        GameCharacter blackPawn3 = new GameCharacter("Black Pawn 3", true, 1, 6, 2, "pawn", 'b');
        GameCharacter blackPawn4 = new GameCharacter("Black Pawn 4", true, 1, 6, 3, "pawn", 'b');
        GameCharacter blackPawn5 = new GameCharacter("Black Pawn 5", true, 1, 6, 4, "pawn", 'b');
        GameCharacter blackPawn6 = new GameCharacter("Black Pawn 6", true, 1, 6, 5, "pawn", 'b');
        GameCharacter blackQueen = new GameCharacter("Black Queen", true, 2, 7, 3, "queen", 'b');
        GameCharacter blackKing = new GameCharacter("Black King", true, 1, 7, 4, "king", 'b');
        aP.add(whitePawn1);
        aP.add(whitePawn2);
        aP.add(whitePawn3);
        aP.add(whitePawn4);
        aP.add(whitePawn5);
        aP.add(whitePawn6);
        aP.add(whiteQueen);
        aP.add(whiteKing);
        aP.add(blackPawn1);
        aP.add(blackPawn2);
        aP.add(blackPawn3);
        aP.add(blackPawn4);
        aP.add(blackPawn5);
        aP.add(blackPawn6);
        aP.add(blackQueen);
        aP.add(blackKing);
        this.turnNum = turnNum;
        this.gameOver = gameOver;
        this.player1Turn = player1Turn;
        this.allPieces = aP;
        this.gb = new GameBoard();
    }
    
    public static Game getGame() {
        if(game==null) {
            game = new Game(1, false, true);
        }
        return game;
    }
    
    public static Game FromScratch() {
        return new Game(1, false, true);
    }
    
    public boolean getTurn(){
        return this.player1Turn;
    }
    
    public void setTurn(boolean bool){
           this.player1Turn = bool;
    }
    
    public int getTurnNum(){
        return this.turnNum;
    }
    
    public void setTurnNum(int value){
        this.turnNum = this.turnNum + value;
    }
    
    public String getTurnNumText(){
        String turnNumText = "Turn #: " + this.turnNum;
        return turnNumText;
    }
    
    public String getPlayerTurnText(){
        String playerTurn;
        if(this.turnNum % 2 == 0){
            playerTurn = ("Player 2's Turn");
        }
        else{
            playerTurn = ("Player 1's Turn");
        }
        return playerTurn;
    }
    
    public ArrayList<GameCharacter> getAllPieces() {
        return allPieces;
    }
    
    public GameCharacter getPieceFromList(int n) {
        return allPieces.get(n);
    }
    
    /**
     * returns the GameCharacter based on the color and name
     * @param color - char color of the piece
     * @param name - String name of the piece
     * @return 
     */
    public GameCharacter getCharacterFromName(String name) {
        GameCharacter piece = new GameCharacter("", false, 0, 0, 0, "", 'w');
        for(int i=0; i<allPieces.size(); i++) {
            if(allPieces.get(i).getName()==name) {
                piece = allPieces.get(i);
            }
        }
        return piece;
    }
    
    public int checkGameStatus() {
        int result = 0;
        if(getCharacterFromName("Black Queen").getLife()==false && getCharacterFromName("Black King").getLife()==false) {
            result = 1;
        }
        else if(getCharacterFromName("White Queen").getLife()==false && getCharacterFromName("White King").getLife()==false) {
            result = 2;
        }
        return result;
    }
    
    public void updateGame(GamePlayer player1, GamePlayer player2) {
        setTurnNum(1);
        player1.addGold(100);
        player2.addGold(100);
        player1.addUltCharge(20);
        player2.addUltCharge(20);
        if(getTurn()==false)
            setTurn(true);
        else if(getTurn()==true)
            setTurn(false); 
    }
    
    public void setFroldianUlt(boolean active) {
        this.froldianUltActive = active;
    }
    
    public boolean getFroldianUlt() {
        return froldianUltActive;
    }
    
    public void setCalidiusUlt(boolean active) {
        this.calidiusUltActive = active;
    }
    
    public boolean getCalidiusUlt() {
        return calidiusUltActive;
    }
    
    public void updateGameCalidiusUlt(GamePlayer user) {
        user.setUltCharge(0);
        setCalidiusUlt(false);
        setTurnNum(1);
        if(getTurn()==false)
            setTurn(true);
        else if(getTurn()==true)
            setTurn(false); 
    }
    
    public void updateGameFroldianUlt(GamePlayer user) {
        setTurnNum(2);
        user.addGold(200);
        user.setUltCharge(0);
        setFroldianUlt(false);
    }
}