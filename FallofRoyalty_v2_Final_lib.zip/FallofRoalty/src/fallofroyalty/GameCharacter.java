package fallofroyalty;

/**
 *
 * @author Justen
 */
public class GameCharacter {
    private String name;                        // name of the piece
    private boolean isAlive;                    // whether the piece is alive or not
    private int mvmt;                           // number of tiles that that piece can move
    private int currRow;                        // current row number that the piece is on
    private int currCol;                        // current collum number that the piece is on
    private String type;                        // what kind of piece it is
    private char color;                         // black or white

    public GameCharacter(String name, boolean isAlive, int mvmt, int currRow, int currCol, String type, char color){
      this.name = name;
      this.isAlive = isAlive;
      this.mvmt = mvmt;
      this.currRow = currRow;
      this.currCol = currCol;
      this.type = type;
      this.color = color;
    }
    
    public void setNewRow(int row){
        this.currRow = row;
    }
    
    public void setNewCol(int col){
        this.currCol = col;
    }
    
    public int getRow(){
        return this.currRow;
    }
    
    public int getCol(){
        return this.currCol;
    }
    
    public String getType(){
        return this.type;
    }
    
    public char getColor(){
        return this.color;
    }
    
    public void setLife(boolean isAlive){
        this.isAlive = isAlive;
    }
    
    public boolean getLife(){
        return this.isAlive;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getMvmt() {
        return this.mvmt;
    }
}